import React from 'react'

export default function EventLocation({ id }) {
  const directionsUrl = 'https://www.google.com/maps/dir/?api=1&destination=Lucknow%2C%20Uttar%20Pradesh'
  return (
    <section id={id} className="location">
      <div className="location-inner">
        <div className="map-box">
          <iframe
            title="Event location on map"
            loading="lazy"
            allowFullScreen
            referrerPolicy="no-referrer-when-downgrade"
            src="https://www.google.com/maps?q=Lucknow,+Uttar+Pradesh&output=embed"
          />
        </div>
        <div className="addr-card">
          <div className="addr-image" aria-hidden="true" />
          <div className="addr-content">
            <div className="addr-title">Address</div>
            <div className="addr-text">Lucknow, Uttar Pradesh</div>
            <a className="btn primary dir-btn" href={directionsUrl} target="_blank" rel="noreferrer">
              Get Directions
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
