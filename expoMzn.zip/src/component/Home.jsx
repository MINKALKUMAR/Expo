import React from 'react'

function Home({ id }) {
  return (
    <section id={id} className="hero">
      <div className="hero-content">
        <div className="hero-card">
          <h1>INDIA'S BIGGEST ELECTRIC MOTOR VEHICLE SHOW</h1>
          <div className="edition">6<sup>th</sup> Edition</div>
          <h2>EV INDIA EXPO 2026</h2>
          <p>An Electric Motor Vehicle Show</p>
          <p className="meta">01-02-03 SEPTEMBER, 2026 | India Expo Centre, Greater Noida, U.P., India</p>
          <div className="cta-row">
            <button className="btn primary">Visitor Registration</button>
            <button className="btn outline">Exhibitor Registration</button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Home

